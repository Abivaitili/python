import random
rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''
user=int(input("Choose 0 for Rock, 1 for paper, 2 for scissors "))
comp=random.randint(0,2)
if user==0 and comp==0:
    print(rock)
    print("computer chose:")
    print(rock)
    print("It's a tie")
elif user==1 and comp==1:
    print(paper)
    print("computer chose:")
    print(paper)
    print("It's a tie")
elif user==2 and comp==2:
    print(scissors)
    print("computer chose:")
    print(scissors)
    print("It's a tie")
elif user==0 and comp==1:
    print(rock)
    print("computer chose:")
    print(paper)
    print("You lose")
elif user==0 and comp==2:
    print(rock)
    print("computer chose:")
    print(scissors)
    print("You win")
elif user==1 and comp==0:
    print(paper)
    print("computer chose:")
    print(rock)
    print("You win")
elif user==1 and comp==2:
    print(paper)
    print("computer chose:")
    print(scissors)
    print("You lose")
elif user==2 and comp==0:
    print(scissors)
    print("computer chose:")
    print(rock)
    print("You lose")
elif user==2 and comp==1:
    print(scissors)
    print("computer chose:")
    print(paper)
    print("You win")
else:
    print("Invalid number")
