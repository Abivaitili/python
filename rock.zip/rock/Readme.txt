                                                   Rock-Paper-Scissors Game 🎮

Welcome to the Rock-Paper-Scissors game! This is a simple Python program developed as a fun project to simulate the classic game. 🎉

📝 Overview

This repository contains a basic implementation of the Rock-Paper-Scissors game using Python.
The game allows you to play against the computer and demonstrates the use of conditional statements and randomization in Python.

📂 Project Structure

index.py: The main Python file containing the logic for the Rock-Paper-Scissors game.
This file was created and tested using the Thonny IDE.

🚀 How to Run

1. Make sure you have Python installed on your system.
If not, download Python and install it.

2. Clone this repository to your local machine

3. Navigate to the project directory:

4. Open the index.py file in Thonny IDE or any Python editor of your choice.

5. Run the program and follow the on-screen instructions to play the game.

This project is licensed under the MIT License.